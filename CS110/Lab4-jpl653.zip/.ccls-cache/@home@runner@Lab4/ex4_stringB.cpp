//Please complete this exercise using the description in the lab notes

#include <iostream>
using namespace std;

int main() {
  //Add your Exercise 4 code here
}