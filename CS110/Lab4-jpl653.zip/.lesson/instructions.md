# File IO and String Processing 

## Lab 4 Video Link
https://youtu.be/2shN8NEIpVQ

## Lab 4 Lab Notes
https://www.labs.cs.uregina.ca/110/fileio/index.html

## Lab Exercise Instructions

1. **Exercise 1**

    Link to open exercise 1 instructions [Click Me](https://www.labs.cs.uregina.ca/110/fileio/exercise2_ggg.html).
    
    We expect you to modify the code `ex1_lab4.cpp`.

    **Input: ** Add `ex1_input.txt` file and enter 10 floating point values.
    1. Declare your own input and output stream to read input from a file.
    2. Use **if** statements to test it input and output files opend successfully.
    
    **Output: ** Output sum and the average of all 10 float values to an output file ex1_output.txt


2. **Exercise 2**

    Link to open exercise 2 instructions [Click Me](https://www.labs.cs.uregina.ca/110/fileio/exercise3_ggg.html).
    
    1. Add your name and your CS 110 Class instructor name in `ex2_input.txt` file.
    2. Modify `ex2_readline.cpp` in such a way that it input 6 line and output 6 lines in reverse order.


3. **Exercise 3**

    Link to open exercise 3 instructions [Click Me](https://www.labs.cs.uregina.ca/110/strings/exercise1_alex.html).
    
    We expect you to modify the code `ex3_stringA.cpp` where it says **ADD CODE HERE: **.
    
    *NOTE: Make sure you read and understand this exercise clearly as you will be using this concept in exercise 4*


4. **Exercise 4**

    Link to open exercise 4 instructions [Click Me](https://www.labs.cs.uregina.ca/110/strings/exercise2_alex.html).
    
    We want you to write code in `ex4_stringB.cpp`.

    Follow the steps mentioned in the exercise 4 instruction page.
    
    ***NOTE:*** 
    1. Make sure you assign exact values in the *orginalString and srch* variables.
    2. Do not count the position of the characters by yourself, use appropriate string functions.
    3. Use the position and lenght of `srch` to complete the substring instructions.

## Submission Instructions
1. Please use this Replit project to do your exercises.
2. If you have completed Exercises 1, 2, 3 and 4, congratulations! You are almost done.
3. **Online Students:** 
   
   Please prepare a .zip file and screenshots as directed in UR Courses
4. **In-person Students:** 

    Demonstrate all completed exercises to your instructor when you are done. Ask about individual exercises only if you are confused or uncertain.
